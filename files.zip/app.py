import os
import sys
import json
import tempfile
import streamlit as st

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Research Paper Analyzer",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@300;400;500&display=swap');

html, body, [class*="css"] {
    font-family: 'Syne', sans-serif;
}

/* Dark background */
.stApp {
    background: #0d0f14;
    color: #e8e6e0;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: #12151c !important;
    border-right: 1px solid #1e2330;
}

/* Header */
.main-header {
    background: linear-gradient(135deg, #0d0f14 0%, #131729 100%);
    border: 1px solid #1e2330;
    border-radius: 12px;
    padding: 2rem 2.5rem;
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
}
.main-header::before {
    content: '';
    position: absolute;
    top: -50%;
    right: -10%;
    width: 400px;
    height: 400px;
    background: radial-gradient(circle, rgba(99,179,237,0.06) 0%, transparent 70%);
    pointer-events: none;
}
.main-header h1 {
    font-size: 2.4rem;
    font-weight: 800;
    letter-spacing: -0.03em;
    color: #f0ede6;
    margin: 0 0 0.3rem 0;
}
.main-header p {
    color: #6b7280;
    font-size: 0.95rem;
    margin: 0;
    font-family: 'DM Mono', monospace;
}
.accent { color: #63b3ed; }

/* Score cards */
.score-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 0.75rem;
    margin: 1rem 0;
}
.score-card {
    background: #12151c;
    border: 1px solid #1e2330;
    border-radius: 8px;
    padding: 0.9rem 1rem;
    text-align: center;
}
.score-card .label {
    font-size: 0.7rem;
    font-family: 'DM Mono', monospace;
    color: #4b5563;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    margin-bottom: 0.3rem;
}
.score-card .value {
    font-size: 1.6rem;
    font-weight: 800;
    color: #63b3ed;
}
.score-card .value.good { color: #68d391; }
.score-card .value.warn { color: #f6ad55; }
.score-card .value.bad  { color: #fc8181; }

/* Agent status */
.agent-log {
    background: #0a0c10;
    border: 1px solid #1a1f2e;
    border-radius: 8px;
    padding: 1rem 1.2rem;
    font-family: 'DM Mono', monospace;
    font-size: 0.8rem;
    color: #9ca3af;
    max-height: 280px;
    overflow-y: auto;
}
.agent-log .log-line { margin: 0.2rem 0; }
.agent-log .log-line.ok { color: #68d391; }
.agent-log .log-line.err { color: #fc8181; }
.agent-log .log-line.info { color: #63b3ed; }

/* Result panels */
.result-panel {
    background: #12151c;
    border: 1px solid #1e2330;
    border-radius: 10px;
    padding: 1.5rem;
    margin-bottom: 1rem;
}
.result-panel h3 {
    color: #f0ede6;
    font-size: 1rem;
    font-weight: 700;
    letter-spacing: 0.02em;
    margin: 0 0 1rem 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.pill {
    display: inline-block;
    background: #1a1f2e;
    border: 1px solid #2d3748;
    border-radius: 20px;
    padding: 0.15rem 0.6rem;
    font-size: 0.7rem;
    font-family: 'DM Mono', monospace;
    color: #63b3ed;
}
.pill.green { color: #68d391; border-color: #276749; background: #1a2e22; }
.pill.orange { color: #f6ad55; border-color: #7b4c0d; background: #2d1f0a; }

/* Buttons */
.stButton button {
    background: #2b6cb0 !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    font-family: 'Syne', sans-serif !important;
    font-weight: 700 !important;
    font-size: 0.95rem !important;
    padding: 0.6rem 1.5rem !important;
    transition: all 0.2s ease !important;
}
.stButton button:hover {
    background: #3182ce !important;
    transform: translateY(-1px) !important;
}

/* Inputs */
.stTextInput input, .stTextArea textarea {
    background: #12151c !important;
    border: 1px solid #1e2330 !important;
    color: #e8e6e0 !important;
    border-radius: 8px !important;
    font-family: 'DM Mono', monospace !important;
}
.stTextInput input:focus, .stTextArea textarea:focus {
    border-color: #63b3ed !important;
    box-shadow: 0 0 0 1px #63b3ed !important;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {
    background: #0d0f14;
    border-bottom: 1px solid #1e2330;
}
.stTabs [data-baseweb="tab"] {
    color: #6b7280 !important;
    font-family: 'Syne', sans-serif !important;
    font-weight: 600 !important;
}
.stTabs [aria-selected="true"] {
    color: #63b3ed !important;
    border-bottom-color: #63b3ed !important;
}

/* Expanders */
.streamlit-expanderHeader {
    background: #12151c !important;
    color: #9ca3af !important;
    border: 1px solid #1e2330 !important;
    border-radius: 8px !important;
    font-family: 'DM Mono', monospace !important;
    font-size: 0.85rem !important;
}

/* Markdown content */
.stMarkdown h1, .stMarkdown h2, .stMarkdown h3 {
    color: #f0ede6 !important;
}
.stMarkdown p, .stMarkdown li {
    color: #9ca3af;
}
.stMarkdown code {
    background: #1a1f2e !important;
    color: #63b3ed !important;
    border-radius: 4px !important;
    font-family: 'DM Mono', monospace !important;
}

.divider {
    border: none;
    border-top: 1px solid #1e2330;
    margin: 1.5rem 0;
}
</style>
""", unsafe_allow_html=True)

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>🔬 Research <span class="accent">Analyzer</span></h1>
    <p>multi-agent · crewai · groq llama-3.3-70b · quality-controlled outputs</p>
</div>
""", unsafe_allow_html=True)

# ── Sidebar ─────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Configuration")

    groq_key = st.text_input(
        "Groq API Key",
        type="password",
        placeholder="gsk_...",
        help="Get your free key at console.groq.com",
    )

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)
    st.markdown("### 🤖 Agent Pipeline")
    st.markdown("""
<div style="font-family:'DM Mono',monospace;font-size:0.75rem;color:#4b5563;line-height:1.8;">
  Boss Agent (Orchestrator)<br>
  ├─ 📄 Paper Analyzer<br>
  │   └─ 🔍 Review Agent<br>
  ├─ 📝 Summary Generator<br>
  │   └─ 🔍 Review Agent<br>
  ├─ 📚 Citation Extractor<br>
  │   └─ 🔍 Review Agent<br>
  ├─ 💡 Insights Agent<br>
  │   └─ 🔍 Review Agent<br>
  └─ 📋 Final Brief Combiner
</div>
""", unsafe_allow_html=True)

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)
    st.markdown("### 📊 Quality Settings")
    threshold = st.slider("Approval Threshold", 5.0, 9.0, 7.0, 0.5)
    max_retries = st.slider("Max Retries per Agent", 1, 3, 2)

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)
    st.caption("Built with CrewAI · Groq · Streamlit")

# ── Main content ───────────────────────────────────────────────────────────────
if not groq_key:
    st.info("👈 Enter your Groq API key in the sidebar to get started.")
    st.markdown("""
**Quick start:**
1. Get a free API key at [console.groq.com](https://console.groq.com)
2. Paste it in the sidebar
3. Upload a PDF or paste an arXiv URL
4. Click **Analyze** and watch the agents work
""")
    st.stop()

# Set API key in env
os.environ["GROQ_API_KEY"] = groq_key

# Input section
input_method = st.radio(
    "Input Method",
    ["📎 Upload PDF", "🔗 arXiv / PDF URL", "📋 Paste Text"],
    horizontal=True,
)

paper_text = ""
paper_source = ""

if input_method == "📎 Upload PDF":
    uploaded = st.file_uploader("Upload research paper PDF", type=["pdf"])
    if uploaded:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(uploaded.read())
            tmp_path = tmp.name
        try:
            from pdf_utils import extract_text_from_pdf
            with st.spinner("Extracting text from PDF..."):
                paper_text = extract_text_from_pdf(tmp_path)
            paper_source = uploaded.name
            st.success(f"✅ Extracted {len(paper_text):,} characters from {uploaded.name}")
        except Exception as e:
            st.error(f"PDF extraction failed: {e}")

elif input_method == "🔗 arXiv / PDF URL":
    url = st.text_input("PDF or arXiv URL", placeholder="https://arxiv.org/abs/2303.08774")
    if url and st.button("Fetch PDF"):
        try:
            from pdf_utils import fetch_pdf_from_url
            with st.spinner("Downloading and extracting..."):
                paper_text = fetch_pdf_from_url(url)
            paper_source = url
            st.success(f"✅ Fetched {len(paper_text):,} characters")
        except Exception as e:
            st.error(f"Failed to fetch PDF: {e}")

elif input_method == "📋 Paste Text":
    paper_text = st.text_area(
        "Paste paper text here",
        height=250,
        placeholder="Paste the full text of the research paper...",
    )
    paper_source = "Pasted text"

# ── Analyze button ─────────────────────────────────────────────────────────────
if paper_text:
    word_count = len(paper_text.split())
    st.caption(f"📄 {word_count:,} words · {len(paper_text):,} chars loaded")

    col1, col2 = st.columns([1, 4])
    with col1:
        analyze = st.button("🚀 Analyze Paper", use_container_width=True)

    if analyze:
        # Status log
        st.markdown("### 🔄 Agent Pipeline")
        log_placeholder = st.empty()
        log_lines = []

        def status_callback(msg: str):
            emoji_map = {"✅": "ok", "❌": "err", "🔄": "info", "📄": "info",
                         "📝": "info", "📚": "info", "💡": "info", "🧠": "info", "🔍": "info"}
            css_cls = next((v for k, v in emoji_map.items() if msg.startswith(k)), "")
            log_lines.append(f'<div class="log-line {css_cls}">{msg}</div>')
            log_placeholder.markdown(
                f'<div class="agent-log">{"".join(log_lines)}</div>',
                unsafe_allow_html=True,
            )

        try:
            from pdf_utils import truncate_for_context
            from crew import run_full_pipeline

            trimmed = truncate_for_context(paper_text, max_chars=12000)
            results = run_full_pipeline(trimmed, status_callback=status_callback)

            st.session_state["results"] = results
            st.session_state["paper_source"] = paper_source

        except Exception as e:
            st.error(f"Pipeline error: {e}")
            st.exception(e)

# ── Results display ────────────────────────────────────────────────────────────
if "results" in st.session_state:
    results = st.session_state["results"]
    source = st.session_state.get("paper_source", "")

    st.markdown("<hr class='divider'>", unsafe_allow_html=True)
    st.markdown("## 📋 Research Brief")

    # Quality scores overview
    def get_score(key):
        r = results.get(key, {}).get("review", {})
        return r.get("score", 0)

    scores = {
        "Analysis": get_score("analysis"),
        "Summary": get_score("summary"),
        "Citations": get_score("citations"),
        "Insights": get_score("insights"),
    }

    def score_class(s):
        if s >= 7.5: return "good"
        if s >= 6.0: return "warn"
        return "bad"

    st.markdown(f"""
<div class="score-grid">
  {''.join(f'''
  <div class="score-card">
    <div class="label">{k}</div>
    <div class="value {score_class(v)}">{v:.1f}</div>
  </div>''' for k, v in scores.items())}
</div>
""", unsafe_allow_html=True)

    # Tabs for different sections
    tabs = st.tabs(["📄 Full Brief", "🔬 Analysis", "📝 Summary", "📚 Citations", "💡 Insights", "🔢 Raw JSON"])

    with tabs[0]:
        final_brief = results.get("final_brief", "")
        st.markdown(final_brief)
        st.download_button(
            "⬇️ Download Research Brief (.md)",
            data=final_brief,
            file_name="research_brief.md",
            mime="text/markdown",
        )

    with tabs[1]:
        parsed = results.get("analysis", {}).get("parsed", {})
        if "raw_output" in parsed:
            st.text(parsed["raw_output"])
        else:
            if parsed.get("title"):
                st.markdown(f"### {parsed.get('title', 'Unknown Title')}")
                cols = st.columns(3)
                cols[0].metric("Authors", ", ".join(parsed.get("authors", [])) or "N/A")
                cols[1].metric("Year", parsed.get("year", "N/A"))
                cols[2].metric("Venue", parsed.get("venue", "N/A"))

            for field, label in [
                ("problem_statement", "🎯 Problem Statement"),
                ("hypothesis", "💭 Hypothesis"),
                ("methodology", "🔧 Methodology"),
                ("experiments", "🧪 Experiments"),
                ("limitations", "⚠️ Limitations"),
            ]:
                if parsed.get(field):
                    with st.expander(label, expanded=True):
                        st.write(parsed[field])

            findings = parsed.get("key_findings", [])
            if findings:
                with st.expander("📊 Key Findings", expanded=True):
                    for i, f in enumerate(findings, 1):
                        st.markdown(f"**{i}.** {f}")

        review = results.get("analysis", {}).get("review", {})
        if review:
            with st.expander("🔍 Review Details"):
                st.json(review)

    with tabs[2]:
        parsed = results.get("summary", {}).get("parsed", {})
        summary_text = parsed.get("summary", results.get("summary", {}).get("output", ""))
        wc = parsed.get("word_count", len(summary_text.split()))
        st.markdown(f"**Word count:** `{wc}` {'✅' if 150 <= wc <= 200 else '⚠️ outside 150-200 target'}")
        st.markdown(f"> {summary_text}")

        review = results.get("summary", {}).get("review", {})
        if review:
            with st.expander("🔍 Review Details"):
                st.json(review)

    with tabs[3]:
        parsed = results.get("citations", {}).get("parsed", {})
        refs = parsed.get("references", [])
        total = parsed.get("total_references", len(refs))
        st.markdown(f"**{total} references extracted**")

        key_works = parsed.get("key_related_works", [])
        if key_works:
            st.markdown("**🌟 Key Related Works:**")
            for kw in key_works:
                st.markdown(f"- {kw}")

        if refs:
            st.markdown("**Full Reference List:**")
            for ref in refs:
                st.markdown(
                    f"`[{ref.get('index', '?')}]` {ref.get('full_reference', ref.get('title', 'Unknown'))}"
                )
        else:
            st.text(results.get("citations", {}).get("output", ""))

        review = results.get("citations", {}).get("review", {})
        if review:
            with st.expander("🔍 Review Details"):
                st.json(review)

    with tabs[4]:
        parsed = results.get("insights", {}).get("parsed", {})
        if "raw_output" in parsed:
            st.text(parsed["raw_output"])
        else:
            takeaways = parsed.get("practical_takeaways", [])
            if takeaways:
                st.markdown("### 💡 Practical Takeaways")
                for t in takeaways:
                    st.markdown(f"**{t.get('takeaway', '')}**")
                    st.caption(t.get("explanation", ""))

            if parsed.get("field_implications"):
                st.markdown("### 🌍 Field Implications")
                st.write(parsed["field_implications"])

            apps = parsed.get("potential_applications", [])
            if apps:
                st.markdown("### 🛠️ Potential Applications")
                for a in apps:
                    st.markdown(f"- {a}")

            questions = parsed.get("open_questions", [])
            if questions:
                st.markdown("### ❓ Open Questions")
                for q in questions:
                    st.markdown(f"- {q}")

            if parsed.get("who_should_read_this"):
                st.markdown("### 👥 Who Should Read This")
                st.write(parsed["who_should_read_this"])

        review = results.get("insights", {}).get("review", {})
        if review:
            with st.expander("🔍 Review Details"):
                st.json(review)

    with tabs[5]:
        st.json({k: v for k, v in results.items() if k != "final_brief"})
