import json
import logging
from typing import Optional
from crewai import Crew, Process

from agents import (
    create_boss_agent,
    create_paper_analyzer_agent,
    create_summary_agent,
    create_citation_agent,
    create_insights_agent,
    create_review_agent,
)
from tasks import (
    create_analysis_task,
    create_review_task,
    create_summary_task,
    create_citation_task,
    create_insights_task,
    create_combine_task,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

QUALITY_THRESHOLD = 7.0
MAX_RETRIES = 2


def parse_json_output(raw: str) -> dict:
    """Safely extract JSON from agent output which may have extra prose."""
    try:
        # Direct parse
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    # Try to find JSON block inside markdown fences
    import re
        
    patterns = [
        r"```json\s*([\s\S]*?)\s*```",
        r"```\s*([\s\S]*?)\s*```",
        r"(\{[\s\S]*\})",
    ]
    for pattern in patterns:
        match = re.search(pattern, raw)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                continue
    logger.warning("Could not parse JSON from output, returning raw string in wrapper")
    return {"raw_output": raw}


def run_agent_with_review(
    agent_task_fn,
    review_agent,
    content_type: str,
    task_kwargs: dict,
    status_callback=None,
) -> tuple[str, dict]:
    """
    Run an agent task and review it. Retry up to MAX_RETRIES if below threshold.
    Returns (raw_output_str, review_result_dict)
    """
    attempt = 0
    last_output = ""
    last_review = {}

    while attempt <= MAX_RETRIES:
        attempt += 1
        if status_callback:
            status_callback(f"🔄 Running {content_type} agent (attempt {attempt}/{MAX_RETRIES + 1})...")

        # Build and run the main agent task
        agent, task = agent_task_fn(**task_kwargs)
        crew = Crew(
            agents=[agent],
            tasks=[task],
            process=Process.sequential,
            verbose=False,
        )
        result = crew.kickoff()
        last_output = str(result)

        # Review the output
        if status_callback:
            status_callback(f"🔍 Reviewing {content_type} output...")

        review_task = create_review_task(review_agent, last_output, content_type, attempt)
        review_crew = Crew(
            agents=[review_agent],
            tasks=[review_task],
            process=Process.sequential,
            verbose=False,
        )
        review_result = review_crew.kickoff()
        last_review = parse_json_output(str(review_result))

        score = last_review.get("score", 0)
        approved = last_review.get("approved", False)

        logger.info(f"{content_type} attempt {attempt}: score={score}, approved={approved}")

        if status_callback:
            status_callback(
                f"{'✅' if approved else '❌'} {content_type} score: {score:.1f}/10 "
                f"({'approved' if approved else 'needs revision'})"
            )

        if approved or attempt > MAX_RETRIES:
            break

        # Inject feedback for next attempt
        feedback = last_review.get("feedback", "")
        if feedback and "paper_text" in task_kwargs:
            task_kwargs["feedback"] = feedback

    return last_output, last_review


def _make_agent_task(agent_fn, task_fn, **kwargs):
    """Helper to create agent+task pair for run_agent_with_review."""
    agent = agent_fn()
    task = task_fn(agent, **kwargs)
    return agent, task


def run_full_pipeline(paper_text: str, status_callback=None) -> dict:
    """
    Main pipeline: runs all agents with review/retry loop.
    Returns a dict with all outputs and the final brief.
    """
    review_agent = create_review_agent()
    results = {}

    # ── 1. Paper Analyzer ──────────────────────────────────────────────────
    if status_callback:
        status_callback("📄 Starting Paper Analysis...")

    analysis_output, analysis_review = run_agent_with_review(
        agent_task_fn=lambda **kw: _make_agent_task(
            create_paper_analyzer_agent, create_analysis_task, **kw
        ),
        review_agent=review_agent,
        content_type="Paper Analysis",
        task_kwargs={"paper_text": paper_text},
        status_callback=status_callback,
    )
    results["analysis"] = {
        "output": analysis_output,
        "parsed": parse_json_output(analysis_output),
        "review": analysis_review,
    }

    # ── 2. Summary Generator ───────────────────────────────────────────────
    if status_callback:
        status_callback("📝 Generating Executive Summary...")

    summary_output, summary_review = run_agent_with_review(
        agent_task_fn=lambda **kw: _make_agent_task(
            create_summary_agent, create_summary_task, **kw
        ),
        review_agent=review_agent,
        content_type="Executive Summary",
        task_kwargs={"analysis": analysis_output},
        status_callback=status_callback,
    )
    results["summary"] = {
        "output": summary_output,
        "parsed": parse_json_output(summary_output),
        "review": summary_review,
    }

    # ── 3. Citation Extractor ──────────────────────────────────────────────
    if status_callback:
        status_callback("📚 Extracting Citations...")

    citation_output, citation_review = run_agent_with_review(
        agent_task_fn=lambda **kw: _make_agent_task(
            create_citation_agent, create_citation_task, **kw
        ),
        review_agent=review_agent,
        content_type="Citations",
        task_kwargs={"paper_text": paper_text},
        status_callback=status_callback,
    )
    results["citations"] = {
        "output": citation_output,
        "parsed": parse_json_output(citation_output),
        "review": citation_review,
    }

    # ── 4. Key Insights Agent ──────────────────────────────────────────────
    if status_callback:
        status_callback("💡 Generating Key Insights...")

    insights_output, insights_review = run_agent_with_review(
        agent_task_fn=lambda **kw: _make_agent_task(
            create_insights_agent, create_insights_task, **kw
        ),
        review_agent=review_agent,
        content_type="Key Insights",
        task_kwargs={"analysis": analysis_output, "summary": summary_output},
        status_callback=status_callback,
    )
    results["insights"] = {
        "output": insights_output,
        "parsed": parse_json_output(insights_output),
        "review": insights_review,
    }

    # ── 5. Boss Agent combines everything ─────────────────────────────────
    if status_callback:
        status_callback("🧠 Boss Agent assembling final research brief...")

    boss = create_boss_agent()
    combine_task = create_combine_task(
        boss,
        analysis=analysis_output,
        summary=summary_output,
        citations=citation_output,
        insights=insights_output,
    )
    final_crew = Crew(
        agents=[boss],
        tasks=[combine_task],
        process=Process.sequential,
        verbose=False,
    )
    final_result = final_crew.kickoff()
    results["final_brief"] = str(final_result)

    if status_callback:
        status_callback("✅ Pipeline complete!")

    return results
